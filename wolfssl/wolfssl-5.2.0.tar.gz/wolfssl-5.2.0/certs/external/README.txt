ca_collection.pem contains the two possible Root CA's that login.live.com can
return, either the Baltimore Cyber Trust Root CA or the DigiCert Global Sign
Root CA.
